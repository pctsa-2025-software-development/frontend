var content=function(){"use strict";var Ht=Object.defineProperty;var Kt=(j,V,H)=>V in j?Ht(j,V,{enumerable:!0,configurable:!0,writable:!0,value:H}):j[V]=H;var G=(j,V,H)=>Kt(j,typeof V!="symbol"?V+"":V,H);var mt,ut;function j(t){return t}var V=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function H(t){return t&&t.__esModule&&Object.prototype.hasOwnProperty.call(t,"default")?t.default:t}var we={exports:{}};(function(t,e){(function(n,r){r(t)})(typeof globalThis<"u"?globalThis:typeof self<"u"?self:V,function(n){if(!(globalThis.chrome&&globalThis.chrome.runtime&&globalThis.chrome.runtime.id))throw new Error("This script should only be loaded in a browser extension.");if(globalThis.browser&&globalThis.browser.runtime&&globalThis.browser.runtime.id)n.exports=globalThis.browser;else{const r="The message port closed before a response was received.",c=l=>{const p={alarms:{clear:{minArgs:0,maxArgs:1},clearAll:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getAll:{minArgs:0,maxArgs:0}},bookmarks:{create:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},getChildren:{minArgs:1,maxArgs:1},getRecent:{minArgs:1,maxArgs:1},getSubTree:{minArgs:1,maxArgs:1},getTree:{minArgs:0,maxArgs:0},move:{minArgs:2,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeTree:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}},browserAction:{disable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},enable:{minArgs:0,maxArgs:1,fallbackToNoCallback:!0},getBadgeBackgroundColor:{minArgs:1,maxArgs:1},getBadgeText:{minArgs:1,maxArgs:1},getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},openPopup:{minArgs:0,maxArgs:0},setBadgeBackgroundColor:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setBadgeText:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},browsingData:{remove:{minArgs:2,maxArgs:2},removeCache:{minArgs:1,maxArgs:1},removeCookies:{minArgs:1,maxArgs:1},removeDownloads:{minArgs:1,maxArgs:1},removeFormData:{minArgs:1,maxArgs:1},removeHistory:{minArgs:1,maxArgs:1},removeLocalStorage:{minArgs:1,maxArgs:1},removePasswords:{minArgs:1,maxArgs:1},removePluginData:{minArgs:1,maxArgs:1},settings:{minArgs:0,maxArgs:0}},commands:{getAll:{minArgs:0,maxArgs:0}},contextMenus:{remove:{minArgs:1,maxArgs:1},removeAll:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},cookies:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:1,maxArgs:1},getAllCookieStores:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},devtools:{inspectedWindow:{eval:{minArgs:1,maxArgs:2,singleCallbackArg:!1}},panels:{create:{minArgs:3,maxArgs:3,singleCallbackArg:!0},elements:{createSidebarPane:{minArgs:1,maxArgs:1}}}},downloads:{cancel:{minArgs:1,maxArgs:1},download:{minArgs:1,maxArgs:1},erase:{minArgs:1,maxArgs:1},getFileIcon:{minArgs:1,maxArgs:2},open:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},pause:{minArgs:1,maxArgs:1},removeFile:{minArgs:1,maxArgs:1},resume:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},extension:{isAllowedFileSchemeAccess:{minArgs:0,maxArgs:0},isAllowedIncognitoAccess:{minArgs:0,maxArgs:0}},history:{addUrl:{minArgs:1,maxArgs:1},deleteAll:{minArgs:0,maxArgs:0},deleteRange:{minArgs:1,maxArgs:1},deleteUrl:{minArgs:1,maxArgs:1},getVisits:{minArgs:1,maxArgs:1},search:{minArgs:1,maxArgs:1}},i18n:{detectLanguage:{minArgs:1,maxArgs:1},getAcceptLanguages:{minArgs:0,maxArgs:0}},identity:{launchWebAuthFlow:{minArgs:1,maxArgs:1}},idle:{queryState:{minArgs:1,maxArgs:1}},management:{get:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},getSelf:{minArgs:0,maxArgs:0},setEnabled:{minArgs:2,maxArgs:2},uninstallSelf:{minArgs:0,maxArgs:1}},notifications:{clear:{minArgs:1,maxArgs:1},create:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:0},getPermissionLevel:{minArgs:0,maxArgs:0},update:{minArgs:2,maxArgs:2}},pageAction:{getPopup:{minArgs:1,maxArgs:1},getTitle:{minArgs:1,maxArgs:1},hide:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setIcon:{minArgs:1,maxArgs:1},setPopup:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},setTitle:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0},show:{minArgs:1,maxArgs:1,fallbackToNoCallback:!0}},permissions:{contains:{minArgs:1,maxArgs:1},getAll:{minArgs:0,maxArgs:0},remove:{minArgs:1,maxArgs:1},request:{minArgs:1,maxArgs:1}},runtime:{getBackgroundPage:{minArgs:0,maxArgs:0},getPlatformInfo:{minArgs:0,maxArgs:0},openOptionsPage:{minArgs:0,maxArgs:0},requestUpdateCheck:{minArgs:0,maxArgs:0},sendMessage:{minArgs:1,maxArgs:3},sendNativeMessage:{minArgs:2,maxArgs:2},setUninstallURL:{minArgs:1,maxArgs:1}},sessions:{getDevices:{minArgs:0,maxArgs:1},getRecentlyClosed:{minArgs:0,maxArgs:1},restore:{minArgs:0,maxArgs:1}},storage:{local:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}},managed:{get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1}},sync:{clear:{minArgs:0,maxArgs:0},get:{minArgs:0,maxArgs:1},getBytesInUse:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}}},tabs:{captureVisibleTab:{minArgs:0,maxArgs:2},create:{minArgs:1,maxArgs:1},detectLanguage:{minArgs:0,maxArgs:1},discard:{minArgs:0,maxArgs:1},duplicate:{minArgs:1,maxArgs:1},executeScript:{minArgs:1,maxArgs:2},get:{minArgs:1,maxArgs:1},getCurrent:{minArgs:0,maxArgs:0},getZoom:{minArgs:0,maxArgs:1},getZoomSettings:{minArgs:0,maxArgs:1},goBack:{minArgs:0,maxArgs:1},goForward:{minArgs:0,maxArgs:1},highlight:{minArgs:1,maxArgs:1},insertCSS:{minArgs:1,maxArgs:2},move:{minArgs:2,maxArgs:2},query:{minArgs:1,maxArgs:1},reload:{minArgs:0,maxArgs:2},remove:{minArgs:1,maxArgs:1},removeCSS:{minArgs:1,maxArgs:2},sendMessage:{minArgs:2,maxArgs:3},setZoom:{minArgs:1,maxArgs:2},setZoomSettings:{minArgs:1,maxArgs:2},update:{minArgs:1,maxArgs:2}},topSites:{get:{minArgs:0,maxArgs:0}},webNavigation:{getAllFrames:{minArgs:1,maxArgs:1},getFrame:{minArgs:1,maxArgs:1}},webRequest:{handlerBehaviorChanged:{minArgs:0,maxArgs:0}},windows:{create:{minArgs:0,maxArgs:1},get:{minArgs:1,maxArgs:2},getAll:{minArgs:0,maxArgs:1},getCurrent:{minArgs:0,maxArgs:1},getLastFocused:{minArgs:0,maxArgs:1},remove:{minArgs:1,maxArgs:1},update:{minArgs:2,maxArgs:2}}};if(Object.keys(p).length===0)throw new Error("api-metadata.json has not been included in browser-polyfill");class w extends WeakMap{constructor(m,f=void 0){super(f),this.createItem=m}get(m){return this.has(m)||this.set(m,this.createItem(m)),super.get(m)}}const b=u=>u&&typeof u=="object"&&typeof u.then=="function",T=(u,m)=>(...f)=>{l.runtime.lastError?u.reject(new Error(l.runtime.lastError.message)):m.singleCallbackArg||f.length<=1&&m.singleCallbackArg!==!1?u.resolve(f[0]):u.resolve(f)},d=u=>u==1?"argument":"arguments",v=(u,m)=>function(x,...I){if(I.length<m.minArgs)throw new Error(`Expected at least ${m.minArgs} ${d(m.minArgs)} for ${u}(), got ${I.length}`);if(I.length>m.maxArgs)throw new Error(`Expected at most ${m.maxArgs} ${d(m.maxArgs)} for ${u}(), got ${I.length}`);return new Promise((_,y)=>{if(m.fallbackToNoCallback)try{x[u](...I,T({resolve:_,reject:y},m))}catch(h){console.warn(`${u} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `,h),x[u](...I),m.fallbackToNoCallback=!1,m.noCallback=!0,_()}else m.noCallback?(x[u](...I),_()):x[u](...I,T({resolve:_,reject:y},m))})},N=(u,m,f)=>new Proxy(m,{apply(x,I,_){return f.call(I,u,..._)}});let D=Function.call.bind(Object.prototype.hasOwnProperty);const a=(u,m={},f={})=>{let x=Object.create(null),I={has(y,h){return h in u||h in x},get(y,h,C){if(h in x)return x[h];if(!(h in u))return;let S=u[h];if(typeof S=="function")if(typeof m[h]=="function")S=N(u,u[h],m[h]);else if(D(f,h)){let q=v(h,f[h]);S=N(u,u[h],q)}else S=S.bind(u);else if(typeof S=="object"&&S!==null&&(D(m,h)||D(f,h)))S=a(S,m[h],f[h]);else if(D(f,"*"))S=a(S,m[h],f["*"]);else return Object.defineProperty(x,h,{configurable:!0,enumerable:!0,get(){return u[h]},set(q){u[h]=q}}),S;return x[h]=S,S},set(y,h,C,S){return h in x?x[h]=C:u[h]=C,!0},defineProperty(y,h,C){return Reflect.defineProperty(x,h,C)},deleteProperty(y,h){return Reflect.deleteProperty(x,h)}},_=Object.create(u);return new Proxy(_,I)},s=u=>({addListener(m,f,...x){m.addListener(u.get(f),...x)},hasListener(m,f){return m.hasListener(u.get(f))},removeListener(m,f){m.removeListener(u.get(f))}}),i=new w(u=>typeof u!="function"?u:function(f){const x=a(f,{},{getContent:{minArgs:0,maxArgs:0}});u(x)}),o=new w(u=>typeof u!="function"?u:function(f,x,I){let _=!1,y,h=new Promise(L=>{y=function(M){_=!0,L(M)}}),C;try{C=u(f,x,y)}catch(L){C=Promise.reject(L)}const S=C!==!0&&b(C);if(C!==!0&&!S&&!_)return!1;const q=L=>{L.then(M=>{I(M)},M=>{let F;M&&(M instanceof Error||typeof M.message=="string")?F=M.message:F="An unexpected error occurred",I({__mozWebExtensionPolyfillReject__:!0,message:F})}).catch(M=>{console.error("Failed to send onMessage rejected reply",M)})};return q(S?C:h),!0}),g=({reject:u,resolve:m},f)=>{l.runtime.lastError?l.runtime.lastError.message===r?m():u(new Error(l.runtime.lastError.message)):f&&f.__mozWebExtensionPolyfillReject__?u(new Error(f.message)):m(f)},A=(u,m,f,...x)=>{if(x.length<m.minArgs)throw new Error(`Expected at least ${m.minArgs} ${d(m.minArgs)} for ${u}(), got ${x.length}`);if(x.length>m.maxArgs)throw new Error(`Expected at most ${m.maxArgs} ${d(m.maxArgs)} for ${u}(), got ${x.length}`);return new Promise((I,_)=>{const y=g.bind(null,{resolve:I,reject:_});x.push(y),f.sendMessage(...x)})},E={devtools:{network:{onRequestFinished:s(i)}},runtime:{onMessage:s(o),onMessageExternal:s(o),sendMessage:A.bind(null,"sendMessage",{minArgs:1,maxArgs:3})},tabs:{sendMessage:A.bind(null,"sendMessage",{minArgs:2,maxArgs:3})}},k={clear:{minArgs:1,maxArgs:1},get:{minArgs:1,maxArgs:1},set:{minArgs:1,maxArgs:1}};return p.privacy={network:{"*":k},services:{"*":k},websites:{"*":k}},a(l,E,p)};n.exports=c(chrome)}})})(we);var dt=we.exports;const K=H(dt),X="pd";function R(t,e){P(t);const n=document.createElement("style");n.id=`${X}-style-${t}`,n.textContent=e,document.head.appendChild(n)}function P(t){var e;(e=document.getElementById(`${X}-style-${t}`))==null||e.remove()}function Y(t){const e=document.getElementById(`${X}-container-${t}`);if(e)return e;const n=document.createElement("div");return n.id=`${X}-container-${t}`,n.setAttribute("data-project-delos",""),document.body.appendChild(n),n}function Z(t){var e;(e=document.getElementById(`${X}-container-${t}`))==null||e.remove()}const ye="text-customization",gt={system:"system-ui, sans-serif",opendyslexic:"OpenDyslexic, system-ui, sans-serif",arial:"Arial, Helvetica, sans-serif",verdana:"Verdana, Geneva, sans-serif","comic-sans":'"Comic Sans MS", cursive, sans-serif'};function ve(t){const e=[];if(t.fontSize!==1&&e.push(`font-size: ${t.fontSize*100}% !important`),t.lineHeight!==1.5&&e.push(`line-height: ${t.lineHeight} !important`),t.letterSpacing!==0&&e.push(`letter-spacing: ${t.letterSpacing}px !important`),t.wordSpacing!==0&&e.push(`word-spacing: ${t.wordSpacing}px !important`),t.fontFamily!=="system"&&e.push(`font-family: ${gt[t.fontFamily]} !important`),e.length===0){Ee();return}R(ye,`body, body * { ${e.join("; ")} }`)}function Ee(){P(ye)}const Te="focus-enhancement",Se="focus-badges";function ke(t){if(Ie(),R(Te,`
    *:focus-visible {
      outline: 3px solid #22d3ee !important;
      outline-offset: 3px !important;
      box-shadow: 0 0 0 5px rgba(34, 211, 238, 0.25) !important;
    }
    [data-pd-skip] {
      position: fixed !important;
      top: 8px !important;
      left: 8px !important;
      z-index: 2147483647 !important;
      padding: 10px 18px !important;
      background: #06b6d4 !important;
      color: #fff !important;
      font: 600 14px/1 system-ui, sans-serif !important;
      border-radius: 8px !important;
      border: none !important;
      cursor: pointer !important;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3) !important;
      text-decoration: none !important;
    }
    [data-pd-tab-badge] {
      position: absolute !important;
      z-index: 2147483646 !important;
      min-width: 18px !important;
      height: 18px !important;
      padding: 0 4px !important;
      background: #9b87f5 !important;
      color: #fff !important;
      font: 700 10px/18px system-ui, sans-serif !important;
      text-align: center !important;
      border-radius: 9px !important;
      pointer-events: none !important;
    }
    `),t.showSkipLink){const e=document.querySelector("main, [role=main], #main-content");if(e){const n=document.createElement("a");n.setAttribute("data-pd-skip",""),n.href="#",n.textContent="Skip to main content",n.addEventListener("click",r=>{r.preventDefault(),e.tabIndex=-1,e.focus()}),document.body.prepend(n)}}if(t.showTabOrder){const e=Y(Se);document.querySelectorAll('a[href], button, input, select, textarea, [tabindex]:not([tabindex="-1"])').forEach((r,c)=>{const l=r.getBoundingClientRect();if(l.width===0&&l.height===0)return;const p=document.createElement("span");p.setAttribute("data-pd-tab-badge",""),p.textContent=String(c+1),p.style.top=`${l.top+window.scrollY-4}px`,p.style.left=`${l.left+window.scrollX-4}px`,e.appendChild(p)})}}function Ie(){var t;P(Te),Z(Se),(t=document.querySelector("[data-pd-skip]"))==null||t.remove()}const Ce="high-contrast",pt={invert:"html { filter: invert(1) hue-rotate(180deg) !important; } img, video, canvas, svg { filter: invert(1) hue-rotate(180deg) !important; }",increased:"html { filter: contrast(1.5) !important; }",dark:"html { filter: invert(1) hue-rotate(180deg) brightness(1.1) !important; } img, video, canvas, svg { filter: invert(1) hue-rotate(180deg) !important; }",light:"html { filter: brightness(1.2) contrast(1.1) !important; } body { background-color: #fff !important; }"};function _e(t){R(Ce,pt[t.mode])}function ft(){P(Ce)}const $e="color-overlay";function Me(t){Le();const e=Y($e);e.style.cssText=`
    position: fixed !important;
    inset: 0 !important;
    z-index: 2147483640 !important;
    pointer-events: none !important;
    background-color: ${t.color} !important;
    opacity: ${t.opacity} !important;
    mix-blend-mode: multiply !important;
  `}function Le(){Z($e)}const Ne="link-highlighter";function Ve(){R(Ne,`
    a[href] {
      text-decoration: underline !important;
      text-underline-offset: 3px !important;
      outline: 2px solid rgba(34, 211, 238, 0.4) !important;
      outline-offset: 2px !important;
      border-radius: 2px !important;
    }
    a[href]:visited {
      outline-color: rgba(155, 135, 245, 0.4) !important;
    }
    a[href]:hover {
      outline-color: rgba(34, 211, 238, 0.8) !important;
      background-color: rgba(34, 211, 238, 0.08) !important;
    }
    a[href]:focus-visible {
      outline: 3px solid #22d3ee !important;
      outline-offset: 3px !important;
    }
    `)}function ht(){P(Ne)}const re="alt-text-inspector";let W=null;function Pe(t){t.innerHTML="",document.querySelectorAll("img").forEach(n=>{const r=n.getBoundingClientRect();if(r.width<10||r.height<10)return;const c=n.hasAttribute("alt")&&n.alt.trim().length>0,l=document.createElement("div");l.setAttribute("data-pd-alt-badge",""),l.className=c?"pd-alt-ok":"pd-alt-missing",l.textContent=c?"ALT":"NO ALT",l.title=c?n.alt:"This image has no alt text",l.style.top=`${r.top+window.scrollY+4}px`,l.style.left=`${r.left+window.scrollX+4}px`,t.appendChild(l)})}function Re(){qe(),R(re,`
    [data-pd-alt-badge] {
      position: absolute !important;
      z-index: 2147483645 !important;
      padding: 2px 6px !important;
      font: 700 10px/1.4 system-ui, sans-serif !important;
      border-radius: 4px !important;
      pointer-events: auto !important;
      cursor: default !important;
    }
    .pd-alt-ok {
      background: rgba(34, 197, 94, 0.85) !important;
      color: #fff !important;
    }
    .pd-alt-missing {
      background: rgba(239, 68, 68, 0.85) !important;
      color: #fff !important;
      animation: pd-pulse 1.5s ease-in-out infinite !important;
    }
    @keyframes pd-pulse {
      50% { opacity: 0.7; }
    }
    `);const t=Y(re);Pe(t),W=new MutationObserver(()=>Pe(t)),W.observe(document.body,{childList:!0,subtree:!0})}function qe(){W==null||W.disconnect(),W=null,P(re),Z(re)}const Fe="reading-guide";let Q=null;function Oe(t){De();const e=Y(Fe),n=document.createElement("div");n.style.cssText=`
    position: fixed !important;
    left: 0 !important;
    right: 0 !important;
    height: ${t.height}px !important;
    background-color: ${t.color} !important;
    opacity: ${t.opacity} !important;
    z-index: 2147483641 !important;
    pointer-events: none !important;
    transition: top 60ms linear !important;
    mix-blend-mode: multiply !important;
  `,e.appendChild(n),Q=r=>{n.style.top=`${r.clientY-t.height/2}px`},document.addEventListener("mousemove",Q,{passive:!0})}function De(){Q&&(document.removeEventListener("mousemove",Q),Q=null),Z(Fe)}const je="tts-highlight";let B=[];function At(t){return t.match(/[^.!?]+[.!?]+/g)??[t]}function bt(t){var p,w;He();const e=At(t);R(je,`
    [data-pd-sentence] {
      transition: background-color 200ms ease !important;
    }
    [data-pd-sentence].pd-speaking {
      background-color: rgba(13, 148, 136, 0.15) !important;
      border-radius: 3px !important;
    }
    `);const n=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT,null),r=[];let c;for(;c=n.nextNode();)(p=c.textContent)!=null&&p.trim()&&r.push(c);let l=0;for(const b of r){const T=b.textContent??"";if(l<e.length&&T.includes(e[l].trim())){const d=document.createElement("span");d.setAttribute("data-pd-sentence",String(l)),(w=b.parentNode)==null||w.replaceChild(d,b),d.appendChild(b),B.push(d),l++}}}function xt(t){var e,n;B.forEach(r=>r.classList.remove("pd-speaking")),(e=B[t])==null||e.classList.add("pd-speaking"),(n=B[t])==null||n.scrollIntoView({behavior:"smooth",block:"center"})}function He(){B.forEach(t=>{const e=t.parentNode;if(e){for(;t.firstChild;)e.insertBefore(t.firstChild,t);e.removeChild(t)}}),B=[],P(je)}const ie="speech-to-text",Ke="stt";let J=null,ee=!1;const wt=`
  #pd-container-${ie} {
    position: fixed !important;
    bottom: 24px !important;
    right: 24px !important;
    z-index: 2147483645 !important;
    font-family: system-ui, sans-serif !important;
    pointer-events: auto !important;
  }
  .pd-stt-pill {
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
    padding: 10px 16px !important;
    border-radius: 999px !important;
    background: rgba(12, 15, 26, 0.92) !important;
    border: 1px solid rgba(34, 211, 238, 0.3) !important;
    backdrop-filter: blur(16px) !important;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4) !important;
    color: #e2e8f0 !important;
    font-size: 13px !important;
    font-weight: 600 !important;
    cursor: pointer !important;
    transition: border-color 150ms ease, box-shadow 150ms ease !important;
    user-select: none !important;
  }
  .pd-stt-pill:hover {
    border-color: rgba(34, 211, 238, 0.5) !important;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), 0 0 16px rgba(34, 211, 238, 0.15) !important;
  }
  .pd-stt-pill[data-listening="true"] {
    border-color: rgba(251, 113, 133, 0.6) !important;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4), 0 0 20px rgba(251, 113, 133, 0.2) !important;
  }
  .pd-stt-dot {
    width: 10px !important;
    height: 10px !important;
    border-radius: 50% !important;
    background: #94a3b8 !important;
    flex-shrink: 0 !important;
    transition: background 200ms ease !important;
  }
  .pd-stt-dot[data-listening="true"] {
    background: #fb7185 !important;
    animation: pd-stt-pulse 1.2s ease-in-out infinite !important;
  }
  @keyframes pd-stt-pulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.5; transform: scale(1.3); }
  }
  .pd-stt-transcript {
    position: fixed !important;
    bottom: 72px !important;
    right: 24px !important;
    max-width: 360px !important;
    max-height: 140px !important;
    overflow-y: auto !important;
    padding: 12px 16px !important;
    border-radius: 12px !important;
    background: rgba(12, 15, 26, 0.92) !important;
    border: 1px solid rgba(255, 255, 255, 0.1) !important;
    backdrop-filter: blur(16px) !important;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.4) !important;
    color: #e2e8f0 !important;
    font-size: 13px !important;
    line-height: 1.5 !important;
    z-index: 2147483644 !important;
    pointer-events: auto !important;
    font-family: system-ui, sans-serif !important;
  }
  .pd-stt-transcript:empty { display: none !important; }
  .pd-stt-interim { color: #94a3b8 !important; font-style: italic !important; }
`;function yt(){const t=window.SpeechRecognition??window.webkitSpeechRecognition;return t?new t:null}function We(){Ue(),R(Ke,wt);const t=Y(ie),e=document.createElement("div");e.className="pd-stt-transcript",t.appendChild(e);const n=document.createElement("button");n.className="pd-stt-pill",n.setAttribute("aria-label","Toggle speech-to-text dictation"),n.innerHTML='<span class="pd-stt-dot"></span><span class="pd-stt-label">Dictate</span>',t.appendChild(n);const r=n.querySelector(".pd-stt-dot"),c=n.querySelector(".pd-stt-label");n.addEventListener("click",()=>{ee?Be():vt(e,n,r,c)})}function vt(t,e,n,r){const c=yt();if(!c){t.textContent="Speech recognition not supported in this browser.";return}J=c,c.continuous=!0,c.interimResults=!0,c.lang=navigator.language||"en-US";let l="";c.onresult=p=>{let w="";for(let b=p.resultIndex;b<p.results.length;b++){const T=p.results[b][0].transcript;p.results[b].isFinal?(l+=T,Et(T)):w+=T}if(t.innerHTML="",l){const b=document.createElement("span");b.textContent=l,t.appendChild(b)}if(w){const b=document.createElement("span");b.className="pd-stt-interim",b.textContent=w,t.appendChild(b)}},c.onerror=p=>{p.error==="aborted"||p.error==="no-speech"||(t.textContent=`Error: ${p.error}`,me(e,n,r))},c.onend=()=>{if(ee)try{c.start()}catch{me(e,n,r)}};try{c.start(),ee=!0,e.setAttribute("data-listening","true"),n.setAttribute("data-listening","true"),r.textContent="Stop"}catch{t.textContent="Could not start speech recognition."}}function Be(){ee=!1,J&&(J.onend=null,J.abort(),J=null);const t=document.getElementById("pd-container-"+ie);if(t){const e=t.querySelector(".pd-stt-pill"),n=t.querySelector(".pd-stt-dot"),r=t.querySelector(".pd-stt-label");e&&n&&r&&me(e,n,r)}}function me(t,e,n){ee=!1,t.setAttribute("data-listening","false"),e.setAttribute("data-listening","false"),n.textContent="Dictate"}function Et(t){const e=document.activeElement;if(e instanceof HTMLInputElement||e instanceof HTMLTextAreaElement){const n=e.selectionStart??e.value.length,r=e.selectionEnd??e.value.length;e.setRangeText(t,n,r,"end"),e.dispatchEvent(new Event("input",{bubbles:!0}))}else if(e&&e.getAttribute("contenteditable")!==null){const n=window.getSelection();if(n&&n.rangeCount>0){const r=n.getRangeAt(0);r.deleteContents(),r.insertNode(document.createTextNode(t)),r.collapse(!1)}}}function Ue(){Be(),Z(ie),P(Ke)}const ze="auto-subtitles",ue="data-pd-subtitled";let te=null;const U=new Map,Tt=`
  .pd-subtitle-wrapper {
    position: relative !important;
    display: inline-block !important;
  }
  .pd-subtitle-bar {
    position: absolute !important;
    bottom: 8px !important;
    left: 50% !important;
    transform: translateX(-50%) !important;
    max-width: 90% !important;
    min-width: 180px !important;
    padding: 8px 14px !important;
    border-radius: 8px !important;
    background: rgba(0, 0, 0, 0.8) !important;
    backdrop-filter: blur(8px) !important;
    color: #fff !important;
    font-size: 14px !important;
    line-height: 1.4 !important;
    text-align: center !important;
    font-family: system-ui, sans-serif !important;
    z-index: 2147483640 !important;
    pointer-events: none !important;
    transition: opacity 200ms ease !important;
    white-space: pre-wrap !important;
    word-wrap: break-word !important;
  }
  .pd-subtitle-bar:empty {
    opacity: 0 !important;
  }
  .pd-subtitle-bar:not(:empty) {
    opacity: 1 !important;
  }
  .pd-subtitle-interim {
    color: #94a3b8 !important;
  }
  .pd-subtitle-badge {
    position: absolute !important;
    top: 8px !important;
    left: 8px !important;
    padding: 2px 8px !important;
    border-radius: 4px !important;
    background: rgba(34, 211, 238, 0.85) !important;
    color: #000 !important;
    font-size: 10px !important;
    font-weight: 700 !important;
    letter-spacing: 0.05em !important;
    text-transform: uppercase !important;
    pointer-events: none !important;
    z-index: 2147483640 !important;
    font-family: system-ui, sans-serif !important;
  }
`;function St(){const t=window.SpeechRecognition??window.webkitSpeechRecognition;return t?new t:null}function Ge(){Xe(),R(ze,Tt),kt(),te=new MutationObserver(t=>{for(const e of t){for(const n of e.addedNodes)if(n instanceof HTMLMediaElement&&de(n),n instanceof HTMLElement)for(const r of n.querySelectorAll("video, audio"))de(r);for(const n of e.removedNodes)if(n instanceof HTMLMediaElement&&ge(n),n instanceof HTMLElement)for(const r of n.querySelectorAll("video, audio"))ge(r)}}),te.observe(document.body,{childList:!0,subtree:!0})}function kt(){for(const t of document.querySelectorAll("video, audio"))de(t)}function de(t){var w;if(t.hasAttribute(ue))return;t.setAttribute(ue,"true");const e=document.createElement("div");e.className="pd-subtitle-wrapper",(w=t.parentElement)==null||w.insertBefore(e,t),e.appendChild(t);const n=document.createElement("div");n.className="pd-subtitle-badge",n.textContent="Live captions",e.appendChild(n);const r=document.createElement("div");r.className="pd-subtitle-bar",r.setAttribute("aria-live","polite"),r.setAttribute("role","status"),e.appendChild(r);const c=St();if(U.set(t,{recognition:c,overlay:r}),!c){r.textContent="Speech recognition not supported";return}c.continuous=!0,c.interimResults=!0,c.lang=navigator.language||"en-US",c.onresult=b=>{let T="",d="";for(let v=b.resultIndex;v<b.results.length;v++){const N=b.results[v][0].transcript;b.results[v].isFinal?T+=N:d+=N}if(r.innerHTML="",T){const v=document.createElement("span");v.textContent=T,r.appendChild(v)}if(d){const v=document.createElement("span");v.className="pd-subtitle-interim",v.textContent=d,r.appendChild(v)}},c.onend=()=>{const b=U.get(t);if(b!=null&&b.recognition&&!t.paused)try{c.start()}catch{}},c.onerror=b=>{b.error==="aborted"||b.error==="no-speech"||(r.textContent=`Caption error: ${b.error}`)};const l=()=>{try{c.start()}catch{}},p=()=>{try{c.abort()}catch{}r.textContent=""};t.addEventListener("play",l),t.addEventListener("pause",p),t.addEventListener("ended",p),t.paused||l()}function ge(t){var r;const e=U.get(t);if(!e)return;if(e.recognition){e.recognition.onend=null,e.recognition.onresult=null;try{e.recognition.abort()}catch{}}const n=t.closest(".pd-subtitle-wrapper");n&&((r=n.parentElement)==null||r.insertBefore(t,n),n.remove()),t.removeAttribute(ue),U.delete(t)}function Xe(){te&&(te.disconnect(),te=null);for(const[t]of U)ge(t);U.clear(),P(ze)}function It(t){return K.runtime.sendMessage(t)}const O="data-pd-smart-alt";let z=null;async function pe(t){if(t.hasAttribute(O)||t.hasAttribute("alt")&&t.alt.trim().length>0||t.naturalWidth<10||t.naturalHeight<10)return;const e=t.currentSrc||t.src;if(!(!e||e.startsWith("data:"))){t.setAttribute(O,"pending");try{const n=await It({type:"AI_GENERATE_ALT",imageUrl:e});n&&"altText"in n&&n.altText?(t.alt=n.altText,t.setAttribute(O,"done")):t.setAttribute(O,"failed")}catch{t.setAttribute(O,"failed")}}}function Ct(){const t=document.querySelectorAll("img");for(const e of t)pe(e)}function Ye(){Ze(),Ct(),z=new MutationObserver(t=>{for(const e of t)for(const n of e.addedNodes)if(n instanceof HTMLImageElement&&pe(n),n instanceof HTMLElement)for(const r of n.querySelectorAll("img"))pe(r)}),z.observe(document.body,{childList:!0,subtree:!0})}function Ze(){z==null||z.disconnect(),z=null;for(const t of document.querySelectorAll(`[${O}]`))t.removeAttribute(O)}const se=(ut=(mt=globalThis.browser)==null?void 0:mt.runtime)!=null&&ut.id?globalThis.browser:globalThis.chrome,_t=new Error("request for lock canceled");var $t=function(t,e,n,r){function c(l){return l instanceof n?l:new n(function(p){p(l)})}return new(n||(n=Promise))(function(l,p){function w(d){try{T(r.next(d))}catch(v){p(v)}}function b(d){try{T(r.throw(d))}catch(v){p(v)}}function T(d){d.done?l(d.value):c(d.value).then(w,b)}T((r=r.apply(t,e||[])).next())})};class Mt{constructor(e,n=_t){this._value=e,this._cancelError=n,this._queue=[],this._weightedWaiters=[]}acquire(e=1,n=0){if(e<=0)throw new Error(`invalid weight ${e}: must be positive`);return new Promise((r,c)=>{const l={resolve:r,reject:c,weight:e,priority:n},p=Qe(this._queue,w=>n<=w.priority);p===-1&&e<=this._value?this._dispatchItem(l):this._queue.splice(p+1,0,l)})}runExclusive(e){return $t(this,arguments,void 0,function*(n,r=1,c=0){const[l,p]=yield this.acquire(r,c);try{return yield n(l)}finally{p()}})}waitForUnlock(e=1,n=0){if(e<=0)throw new Error(`invalid weight ${e}: must be positive`);return this._couldLockImmediately(e,n)?Promise.resolve():new Promise(r=>{this._weightedWaiters[e-1]||(this._weightedWaiters[e-1]=[]),Lt(this._weightedWaiters[e-1],{resolve:r,priority:n})})}isLocked(){return this._value<=0}getValue(){return this._value}setValue(e){this._value=e,this._dispatchQueue()}release(e=1){if(e<=0)throw new Error(`invalid weight ${e}: must be positive`);this._value+=e,this._dispatchQueue()}cancel(){this._queue.forEach(e=>e.reject(this._cancelError)),this._queue=[]}_dispatchQueue(){for(this._drainUnlockWaiters();this._queue.length>0&&this._queue[0].weight<=this._value;)this._dispatchItem(this._queue.shift()),this._drainUnlockWaiters()}_dispatchItem(e){const n=this._value;this._value-=e.weight,e.resolve([n,this._newReleaser(e.weight)])}_newReleaser(e){let n=!1;return()=>{n||(n=!0,this.release(e))}}_drainUnlockWaiters(){if(this._queue.length===0)for(let e=this._value;e>0;e--){const n=this._weightedWaiters[e-1];n&&(n.forEach(r=>r.resolve()),this._weightedWaiters[e-1]=[])}else{const e=this._queue[0].priority;for(let n=this._value;n>0;n--){const r=this._weightedWaiters[n-1];if(!r)continue;const c=r.findIndex(l=>l.priority<=e);(c===-1?r:r.splice(0,c)).forEach(l=>l.resolve())}}}_couldLockImmediately(e,n){return(this._queue.length===0||this._queue[0].priority<n)&&e<=this._value}}function Lt(t,e){const n=Qe(t,r=>e.priority<=r.priority);t.splice(n+1,0,e)}function Qe(t,e){for(let n=t.length-1;n>=0;n--)if(e(t[n]))return n;return-1}var Nt=function(t,e,n,r){function c(l){return l instanceof n?l:new n(function(p){p(l)})}return new(n||(n=Promise))(function(l,p){function w(d){try{T(r.next(d))}catch(v){p(v)}}function b(d){try{T(r.throw(d))}catch(v){p(v)}}function T(d){d.done?l(d.value):c(d.value).then(w,b)}T((r=r.apply(t,e||[])).next())})};class Vt{constructor(e){this._semaphore=new Mt(1,e)}acquire(){return Nt(this,arguments,void 0,function*(e=0){const[,n]=yield this._semaphore.acquire(1,e);return n})}runExclusive(e,n=0){return this._semaphore.runExclusive(()=>e(),1,n)}isLocked(){return this._semaphore.isLocked()}waitForUnlock(e=0){return this._semaphore.waitForUnlock(1,e)}release(){this._semaphore.isLocked()&&this._semaphore.release()}cancel(){return this._semaphore.cancel()}}var Je=Object.prototype.hasOwnProperty;function fe(t,e){var n,r;if(t===e)return!0;if(t&&e&&(n=t.constructor)===e.constructor){if(n===Date)return t.getTime()===e.getTime();if(n===RegExp)return t.toString()===e.toString();if(n===Array){if((r=t.length)===e.length)for(;r--&&fe(t[r],e[r]););return r===-1}if(!n||typeof t=="object"){r=0;for(n in t)if(Je.call(t,n)&&++r&&!Je.call(e,n)||!(n in e)||!fe(t[n],e[n]))return!1;return Object.keys(e).length===r}}return t!==t&&e!==e}const $=Pt();function Pt(){const t={local:ae("local"),session:ae("session"),sync:ae("sync"),managed:ae("managed")},e=a=>{const s=t[a];if(s==null){const i=Object.keys(t).join(", ");throw Error(`Invalid area "${a}". Options: ${i}`)}return s},n=a=>{const s=a.indexOf(":"),i=a.substring(0,s),o=a.substring(s+1);if(o==null)throw Error(`Storage key should be in the form of "area:key", but received "${a}"`);return{driverArea:i,driverKey:o,driver:e(i)}},r=a=>a+"$",c=(a,s)=>{const i={...a};return Object.entries(s).forEach(([o,g])=>{g==null?delete i[o]:i[o]=g}),i},l=(a,s)=>a??s??null,p=a=>typeof a=="object"&&!Array.isArray(a)?a:{},w=async(a,s,i)=>l(await a.getItem(s),(i==null?void 0:i.fallback)??(i==null?void 0:i.defaultValue)),b=async(a,s)=>{const i=r(s);return p(await a.getItem(i))},T=async(a,s,i)=>{await a.setItem(s,i??null)},d=async(a,s,i)=>{const o=r(s),g=p(await a.getItem(o));await a.setItem(o,c(g,i))},v=async(a,s,i)=>{if(await a.removeItem(s),i!=null&&i.removeMeta){const o=r(s);await a.removeItem(o)}},N=async(a,s,i)=>{const o=r(s);if(i==null)await a.removeItem(o);else{const g=p(await a.getItem(o));[i].flat().forEach(A=>delete g[A]),await a.setItem(o,g)}},D=(a,s,i)=>a.watch(s,i);return{getItem:async(a,s)=>{const{driver:i,driverKey:o}=n(a);return await w(i,o,s)},getItems:async a=>{const s=new Map,i=new Map,o=[];a.forEach(A=>{let E,k;typeof A=="string"?E=A:"getValue"in A?(E=A.key,k={fallback:A.fallback}):(E=A.key,k=A.options),o.push(E);const{driverArea:u,driverKey:m}=n(E),f=s.get(u)??[];s.set(u,f.concat(m)),i.set(E,k)});const g=new Map;return await Promise.all(Array.from(s.entries()).map(async([A,E])=>{(await t[A].getItems(E)).forEach(k=>{const u=`${A}:${k.key}`,m=i.get(u),f=l(k.value,(m==null?void 0:m.fallback)??(m==null?void 0:m.defaultValue));g.set(u,f)})})),o.map(A=>({key:A,value:g.get(A)}))},getMeta:async a=>{const{driver:s,driverKey:i}=n(a);return await b(s,i)},getMetas:async a=>{const s=a.map(g=>{const A=typeof g=="string"?g:g.key,{driverArea:E,driverKey:k}=n(A);return{key:A,driverArea:E,driverKey:k,driverMetaKey:r(k)}}),i=s.reduce((g,A)=>{var E;return g[E=A.driverArea]??(g[E]=[]),g[A.driverArea].push(A),g},{}),o={};return await Promise.all(Object.entries(i).map(async([g,A])=>{const E=await se.storage[g].get(A.map(k=>k.driverMetaKey));A.forEach(k=>{o[k.key]=E[k.driverMetaKey]??{}})})),s.map(g=>({key:g.key,meta:o[g.key]}))},setItem:async(a,s)=>{const{driver:i,driverKey:o}=n(a);await T(i,o,s)},setItems:async a=>{const s={};a.forEach(i=>{const{driverArea:o,driverKey:g}=n("key"in i?i.key:i.item.key);s[o]??(s[o]=[]),s[o].push({key:g,value:i.value})}),await Promise.all(Object.entries(s).map(async([i,o])=>{await e(i).setItems(o)}))},setMeta:async(a,s)=>{const{driver:i,driverKey:o}=n(a);await d(i,o,s)},setMetas:async a=>{const s={};a.forEach(i=>{const{driverArea:o,driverKey:g}=n("key"in i?i.key:i.item.key);s[o]??(s[o]=[]),s[o].push({key:g,properties:i.meta})}),await Promise.all(Object.entries(s).map(async([i,o])=>{const g=e(i),A=o.map(({key:m})=>r(m)),E=await g.getItems(A),k=Object.fromEntries(E.map(({key:m,value:f})=>[m,p(f)])),u=o.map(({key:m,properties:f})=>{const x=r(m);return{key:x,value:c(k[x]??{},f)}});await g.setItems(u)}))},removeItem:async(a,s)=>{const{driver:i,driverKey:o}=n(a);await v(i,o,s)},removeItems:async a=>{const s={};a.forEach(i=>{let o,g;typeof i=="string"?o=i:"getValue"in i?o=i.key:"item"in i?(o=i.item.key,g=i.options):(o=i.key,g=i.options);const{driverArea:A,driverKey:E}=n(o);s[A]??(s[A]=[]),s[A].push(E),g!=null&&g.removeMeta&&s[A].push(r(E))}),await Promise.all(Object.entries(s).map(async([i,o])=>{await e(i).removeItems(o)}))},clear:async a=>{await e(a).clear()},removeMeta:async(a,s)=>{const{driver:i,driverKey:o}=n(a);await N(i,o,s)},snapshot:async(a,s)=>{var o;const i=await e(a).snapshot();return(o=s==null?void 0:s.excludeKeys)==null||o.forEach(g=>{delete i[g],delete i[r(g)]}),i},restoreSnapshot:async(a,s)=>{await e(a).restoreSnapshot(s)},watch:(a,s)=>{const{driver:i,driverKey:o}=n(a);return D(i,o,s)},unwatch(){Object.values(t).forEach(a=>{a.unwatch()})},defineItem:(a,s)=>{const{driver:i,driverKey:o}=n(a),{version:g=1,migrations:A={},onMigrationComplete:E,debug:k=!1}=s??{};if(g<1)throw Error("Storage item version cannot be less than 1. Initial versions should be set to 1, not 0.");let u=!1;const m=async()=>{var M;const y=r(o),[{value:h},{value:C}]=await i.getItems([o,y]);if(u=h==null&&(C==null?void 0:C.v)==null&&!!g,h==null)return;const S=(C==null?void 0:C.v)??1;if(S>g)throw Error(`Version downgrade detected (v${S} -> v${g}) for "${a}"`);if(S===g)return;k&&console.debug(`[@wxt-dev/storage] Running storage migration for ${a}: v${S} -> v${g}`);const q=Array.from({length:g-S},(F,xe)=>S+xe+1);let L=h;for(const F of q)try{L=await((M=A==null?void 0:A[F])==null?void 0:M.call(A,L))??L,k&&console.debug(`[@wxt-dev/storage] Storage migration processed for version: v${F}`)}catch(xe){throw new Rt(a,F,{cause:xe})}await i.setItems([{key:o,value:L},{key:y,value:{...C,v:g}}]),k&&console.debug(`[@wxt-dev/storage] Storage migration completed for ${a} v${g}`,{migratedValue:L}),E==null||E(L,g)},f=(s==null?void 0:s.migrations)==null?Promise.resolve():m().catch(y=>{console.error(`[@wxt-dev/storage] Migration failed for ${a}`,y)}),x=new Vt,I=()=>(s==null?void 0:s.fallback)??(s==null?void 0:s.defaultValue)??null,_=()=>x.runExclusive(async()=>{const y=await i.getItem(o);if(y!=null||(s==null?void 0:s.init)==null)return y;const h=await s.init();return await i.setItem(o,h),y==null&&g>1&&await d(i,o,{v:g}),h});return f.then(_),{key:a,get defaultValue(){return I()},get fallback(){return I()},getValue:async()=>(await f,s!=null&&s.init?await _():await w(i,o,s)),getMeta:async()=>(await f,await b(i,o)),setValue:async y=>{await f,u?(u=!1,await Promise.all([T(i,o,y),d(i,o,{v:g})])):await T(i,o,y)},setMeta:async y=>(await f,await d(i,o,y)),removeValue:async y=>(await f,await v(i,o,y)),removeMeta:async y=>(await f,await N(i,o,y)),watch:y=>D(i,o,(h,C)=>y(h??I(),C??I())),migrate:m}}}}function ae(t){const e=()=>{if(se.runtime==null)throw Error(`'wxt/storage' must be loaded in a web extension environment

 - If thrown during a build, see https://github.com/wxt-dev/wxt/issues/371
 - If thrown during tests, mock 'wxt/browser' correctly. See https://wxt.dev/guide/go-further/testing.html
`);if(se.storage==null)throw Error("You must add the 'storage' permission to your manifest to use 'wxt/storage'");const r=se.storage[t];if(r==null)throw Error(`"browser.storage.${t}" is undefined`);return r},n=new Set;return{getItem:async r=>(await e().get(r))[r],getItems:async r=>{const c=await e().get(r);return r.map(l=>({key:l,value:c[l]??null}))},setItem:async(r,c)=>{c==null?await e().remove(r):await e().set({[r]:c})},setItems:async r=>{const c=r.reduce((l,{key:p,value:w})=>(l[p]=w,l),{});await e().set(c)},removeItem:async r=>{await e().remove(r)},removeItems:async r=>{await e().remove(r)},clear:async()=>{await e().clear()},snapshot:async()=>await e().get(),restoreSnapshot:async r=>{await e().set(r)},watch(r,c){const l=p=>{const w=p[r];w==null||fe(w.newValue,w.oldValue)||c(w.newValue??null,w.oldValue??null)};return e().onChanged.addListener(l),n.add(l),()=>{e().onChanged.removeListener(l),n.delete(l)}},unwatch(){n.forEach(r=>{e().onChanged.removeListener(r)}),n.clear()}}}var Rt=class extends Error{constructor(t,e,n){super(`v${e} migration failed for "${t}"`,n),this.key=t,this.version=e}};const et=$.defineItem("sync:textCustomization",{defaultValue:{enabled:!1,fontSize:1,lineHeight:1.5,letterSpacing:0,wordSpacing:0,fontFamily:"system"}}),tt=$.defineItem("sync:focusEnhancement",{defaultValue:{enabled:!1,showTabOrder:!0,showSkipLink:!0}}),nt=$.defineItem("sync:highContrast",{defaultValue:{enabled:!1,mode:"increased"}}),rt=$.defineItem("sync:colorOverlay",{defaultValue:{enabled:!1,color:"#ffff00",opacity:.15}}),it=$.defineItem("sync:linkHighlighter",{defaultValue:{enabled:!1}}),st=$.defineItem("sync:altTextInspector",{defaultValue:{enabled:!1}}),at=$.defineItem("sync:readingGuide",{defaultValue:{enabled:!1,height:8,color:"#22d3ee",opacity:.3}});$.defineItem("sync:tts",{defaultValue:{enabled:!1,rate:1,pitch:1,voice:""}}),$.defineItem("sync:aiConfig",{defaultValue:{apiKey:"",provider:"openai"}}),$.defineItem("sync:pageSummary",{defaultValue:{enabled:!1}});const ot=$.defineItem("sync:speechToText",{defaultValue:{enabled:!1}}),lt=$.defineItem("sync:autoSubtitles",{defaultValue:{enabled:!1}}),ct=$.defineItem("sync:smartAltText",{defaultValue:{enabled:!1}}),qt={matches:["<all_urls>"],async main(){const t=await et.getValue();t.enabled&&ve(t);const e=await tt.getValue();e.enabled&&ke(e);const n=await nt.getValue();n.enabled&&_e(n);const r=await rt.getValue();r.enabled&&Me(r),(await it.getValue()).enabled&&Ve(),(await st.getValue()).enabled&&Re();const p=await at.getValue();p.enabled&&Oe(p),(await ot.getValue()).enabled&&We(),(await lt.getValue()).enabled&&Ge(),(await ct.getValue()).enabled&&Ye(),et.watch(d=>d.enabled?ve(d):Ee()),tt.watch(d=>d.enabled?ke(d):Ie()),nt.watch(d=>d.enabled?_e(d):ft()),rt.watch(d=>d.enabled?Me(d):Le()),it.watch(d=>d.enabled?Ve():ht()),st.watch(d=>d.enabled?Re():qe()),at.watch(d=>d.enabled?Oe(d):De()),ot.watch(d=>d.enabled?We():Ue()),lt.watch(d=>d.enabled?Ge():Xe()),ct.watch(d=>d.enabled?Ye():Ze()),K.runtime.onMessage.addListener(d=>{var N;const v=d;switch(v.type){case"TTS_PREPARE_HIGHLIGHT":bt(v.text);break;case"TTS_HIGHLIGHT":xt(v.sentenceIndex);break;case"TTS_CLEANUP_HIGHLIGHT":He();break;case"GET_PAGE_TEXT":return Promise.resolve({type:"PAGE_TEXT",text:document.body.innerText});case"GET_SELECTED_TEXT":return Promise.resolve({type:"SELECTED_TEXT",text:((N=window.getSelection())==null?void 0:N.toString())??""})}})}};function oe(t,...e){}const Ft={debug:(...t)=>oe(console.debug,...t),log:(...t)=>oe(console.log,...t),warn:(...t)=>oe(console.warn,...t),error:(...t)=>oe(console.error,...t)},Ot={},ce=class ce extends Event{constructor(e,n){super(ce.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=n}};G(ce,"EVENT_NAME",Ae("wxt:locationchange"));let he=ce;function Ae(t){var n;const e=typeof Ot>"u"?"build":"content";return`${(n=K==null?void 0:K.runtime)==null?void 0:n.id}:${e}:${t}`}function Dt(t){let e,n;return{run(){e==null&&(n=new URL(location.href),e=t.setInterval(()=>{let r=new URL(location.href);r.href!==n.href&&(window.dispatchEvent(new he(r,n)),n=r)},1e3))}}}const ne=class ne{constructor(e,n){G(this,"isTopFrame",window.self===window.top);G(this,"abortController");G(this,"locationWatcher",Dt(this));this.contentScriptName=e,this.options=n,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return K.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,n){const r=setInterval(()=>{this.isValid&&e()},n);return this.onInvalidated(()=>clearInterval(r)),r}setTimeout(e,n){const r=setTimeout(()=>{this.isValid&&e()},n);return this.onInvalidated(()=>clearTimeout(r)),r}requestAnimationFrame(e){const n=requestAnimationFrame((...r)=>{this.isValid&&e(...r)});return this.onInvalidated(()=>cancelAnimationFrame(n)),n}requestIdleCallback(e,n){const r=requestIdleCallback((...c)=>{this.signal.aborted||e(...c)},n);return this.onInvalidated(()=>cancelIdleCallback(r)),r}addEventListener(e,n,r,c){var l;n==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(l=e.addEventListener)==null||l.call(e,n.startsWith("wxt:")?Ae(n):n,r,{...c,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Ft.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:ne.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName},"*")}listenForNewerScripts(e){let n=!0;const r=c=>{var l,p;if(((l=c.data)==null?void 0:l.type)===ne.SCRIPT_STARTED_MESSAGE_TYPE&&((p=c.data)==null?void 0:p.contentScriptName)===this.contentScriptName){const w=n;if(n=!1,w&&(e!=null&&e.ignoreFirstEvent))return;this.notifyInvalidated()}};addEventListener("message",r),this.onInvalidated(()=>removeEventListener("message",r))}};G(ne,"SCRIPT_STARTED_MESSAGE_TYPE",Ae("wxt:content-script-started"));let be=ne;function Bt(){}function le(t,...e){}const jt={debug:(...t)=>le(console.debug,...t),log:(...t)=>le(console.log,...t),warn:(...t)=>le(console.warn,...t),error:(...t)=>le(console.error,...t)};return(async()=>{try{const{main:t,...e}=qt,n=new be("content",e);return await t(n)}catch(t){throw jt.error('The content script "content" crashed on startup!',t),t}})()}();
content;
